<?php 
require("countryconnection.php");

if(isset($_POST['countries']))
{
	$query = "SELECT * FROM Country where name = '{$_POST['countries']}'";
	$_SESSION['Country'] = fetch_record($query);
	header('Location: country.php');
}



if(isset($_POST['countries']))
{
	$query = "SELECT * FROM City where ID = '{$_POST['table']}' ";
	$_SESSION['City'] = fetch_all($query);
	header('Location: country.php');

}
?>
