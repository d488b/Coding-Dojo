<?php 
require("countryconnection.php");
$query = "SELECT * FROM Country";
$countries = fetch_all($query);
$query = "SELECT City.ID, City.Name, City.District, City.Population FROM City LEFT JOIN Country ON City.CountryCode=Country.Code;"
?>
<html lang="en">
<!-- Don't know how to insert data from database into table -->
<!-- The query I used to join City info and Country info together works but I don't know where to place it in order to retrieve the data   -->
<head>
	<meta charset="UTF-8">
	<title>Green Belt Exam</title>
	<script type="text/javascript" src="/path/to/jquery-latest.js"></script> 
	<script type="text/javascript" src="/path/to/jquery.tablesorter.js"></script> 
	<script type="text/javascript">	
		$(document).ready(function(){ 
        $("#table").tablesorter(); 
    	}); 
    	//Not sure if table sorter is working properly. //
	</script>
</head>
<body>
	<div id="Container">
		<form action="countryprocess.php" method="post">
			<label>Select a Country: </label>
			<select name="countries" id="countries">
<?php 			foreach($countries as $country)
				{ ?>
					<option value="<?= $country['Name'] ?>"><?= $country['Name'] ?></option>
<?php			} ?>
			</select>
			<input type="submit" value="Show Data">
		</form>
<?php   if(isset($_SESSION['Country']))
		{ ?> 
			<div>	
				<table id="table" class="tablesorter">
				<thead>
				<tr>
					<th>City ID</th>
					<th>City Name</th>
					<th>District</th>
					<th>Population</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td><?= $_SESSION['City']['ID'] ?></td>
					<td><?= $_SESSION['City']['Name'] ?></td>
					<td><?= $_SESSION['City']['District'] ?></td>
					<td><?= $_SESSION['City']['Population'] ?></td>
				</tr>
				</tbody>
			</div>
			<div>
				<table id="table2" class="tablesorter">
				<thead>
				<tr>
					<th>Language</th>
					<th>Percentage</th>
					<th>Population of People Speaking the Language</th>
					<th>Country's Official Language</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td><?= $_SESSION['CountryLanguage']['Language'] ?></td>
					<td><?= $_SESSION['CountryLanguage']['Percentage'] ?></td>
					<td><?= $_SESSION//Not sure how to post Country.Population and CountryLanguage.Percentage together?></td>
					<td><?= $_SESSION['CountryLanguage']['IsOfficial'] ?></td>
				</tr>
				</tbody>
<?php	} ?>
	</div>
</body>
</html>

<?php 
unset($_SESSION['Country']);
?>